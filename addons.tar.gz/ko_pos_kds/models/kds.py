# -*- coding: utf-8 -*-
import json

from odoo import api, fields, models


def _clean_note(note):
    """POS line notes arrive as JSON arrays like '[{"text": "..."}]' — flatten to text."""
    if not note:
        return ''
    s = str(note).strip()
    if s.startswith('['):
        try:
            arr = json.loads(s)
            return ', '.join(
                (x.get('text', '') if isinstance(x, dict) else str(x))
                for x in arr if x
            ).strip(', ')
        except (ValueError, TypeError):
            return s
    return s


class KdsStation(models.Model):
    _name = 'ko.kds.station'
    _description = 'KDS Station (จุดเตรียมอาหาร)'
    _order = 'sequence, id'

    name = fields.Char(required=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    category_ids = fields.Many2many(
        'pos.category', string='หมวดสินค้าที่แสดง',
        help='แสดงเฉพาะรายการในหมวดเหล่านี้ (เว้นว่าง = แสดงทุกหมวด)')


class KdsTicket(models.Model):
    _name = 'ko.kds.ticket'
    _description = 'KDS Ticket (ตั๋วครัว)'
    _order = 'id desc'

    name = fields.Char(default='/', readonly=True)
    pos_order_uuid = fields.Char(index=True)
    pos_reference = fields.Char(string='เลขที่ออเดอร์')
    tracking_number = fields.Char(string='คิว')
    config_id = fields.Many2one('pos.config', string='POS')
    table_name = fields.Char(string='โต๊ะ')
    floor_name = fields.Char(string='โซน')
    internal_note = fields.Text()
    general_customer_note = fields.Text()
    state = fields.Selection([
        ('new', 'ใหม่'),
        ('progress', 'กำลังทำ'),
        ('done', 'เสร็จแล้ว'),
    ], default='new', index=True)
    done_time = fields.Datetime()
    line_ids = fields.One2many('ko.kds.ticket.line', 'ticket_id')

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', '/') == '/':
                vals['name'] = self.env['ir.sequence'].next_by_code('ko.kds.ticket') or '/'
        return super().create(vals_list)

    @api.model
    def create_from_pos(self, payload):
        """Called from the POS client each time an order is sent to the kitchen."""
        Product = self.env['product.product']

        def _prep_lines(lines, cancelled):
            cmds = []
            for line in lines or []:
                product = Product.browse(line.get('product_id')) if line.get('product_id') else Product
                cmds.append((0, 0, {
                    'product_id': product.id or False,
                    'full_name': line.get('name') or line.get('display_name') or '?',
                    'qty': line.get('quantity') or 0,
                    'note': _clean_note(line.get('note')),
                    'customer_note': _clean_note(line.get('customer_note')),
                    'attribute_names': ', '.join(line.get('attribute_value_names') or []),
                    'cancelled': cancelled,
                    'pos_categ_ids': [(6, 0, product.pos_categ_ids.ids)] if product else False,
                }))
            return cmds

        line_cmds = _prep_lines(payload.get('new'), False) + _prep_lines(payload.get('cancelled'), True)
        if not line_cmds and not payload.get('internal_note') and not payload.get('general_customer_note'):
            return False

        ticket = self.sudo().create({
            'pos_order_uuid': payload.get('order_uuid'),
            'pos_reference': payload.get('pos_reference'),
            'tracking_number': str(payload.get('tracking_number') or ''),
            'config_id': payload.get('config_id'),
            'table_name': str(payload.get('table') or ''),
            'floor_name': payload.get('floor') or '',
            'internal_note': _clean_note(payload.get('internal_note')),
            'general_customer_note': _clean_note(payload.get('general_customer_note')),
            'line_ids': line_cmds,
        })
        return ticket.id

    def set_kds_state(self, state):
        vals = {'state': state}
        if state == 'done':
            vals['done_time'] = fields.Datetime.now()
        self.sudo().write(vals)
        return True


class KdsTicketLine(models.Model):
    _name = 'ko.kds.ticket.line'
    _description = 'KDS Ticket Line'
    _order = 'id'

    ticket_id = fields.Many2one('ko.kds.ticket', required=True, ondelete='cascade', index=True)
    product_id = fields.Many2one('product.product')
    full_name = fields.Char()
    qty = fields.Float()
    note = fields.Char()
    customer_note = fields.Char()
    attribute_names = fields.Char()
    cancelled = fields.Boolean(default=False)
    done = fields.Boolean(default=False)
    pos_categ_ids = fields.Many2many('pos.category', string='หมวด')

    def toggle_done(self):
        for line in self:
            line.sudo().done = not line.done
        return True
