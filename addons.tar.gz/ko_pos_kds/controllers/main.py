# -*- coding: utf-8 -*-
import json

from odoo import fields, http
from odoo.http import request


class KdsController(http.Controller):

    def _check_access(self):
        if not request.env.user.has_group('point_of_sale.group_pos_user'):
            return False
        return True

    @http.route(['/kds', '/kds/<int:station_id>'], auth='user', type='http', website=False)
    def kds_screen(self, station_id=None, **kw):
        if not self._check_access():
            return request.make_response('Forbidden', status=403)
        stations = request.env['ko.kds.station'].search([])
        station = stations.filtered(lambda s: s.id == station_id) or stations[:1]
        return request.render('ko_pos_kds.kds_page', {
            'stations': stations,
            'station': station,
            'csrf_token': request.csrf_token(),
        })

    @http.route('/kds/data', auth='user', type='http', methods=['GET'])
    def kds_data(self, station_id=None, **kw):
        if not self._check_access():
            return request.make_response('{"error": "forbidden"}', headers=[('Content-Type', 'application/json')])
        env = request.env
        station = env['ko.kds.station'].browse(int(station_id)) if station_id else env['ko.kds.station']
        categ_ids = set(station.category_ids.ids) if station and station.category_ids else None

        # Active tickets + recently finished ones (last 30 min)
        recent_limit = fields.Datetime.subtract(fields.Datetime.now(), minutes=30)
        tickets = env['ko.kds.ticket'].search([
            '|', ('state', 'in', ['new', 'progress']),
            '&', ('state', '=', 'done'), ('done_time', '>=', recent_limit),
        ], order='id asc', limit=200)

        result = []
        for t in tickets:
            lines = []
            for line in t.line_ids:
                if categ_ids is not None and line.pos_categ_ids and not (set(line.pos_categ_ids.ids) & categ_ids):
                    continue
                lines.append({
                    'id': line.id,
                    'name': line.full_name,
                    'qty': line.qty,
                    'note': ' '.join(x for x in [line.note, line.customer_note] if x),
                    'attrs': line.attribute_names or '',
                    'cancelled': line.cancelled,
                    'done': line.done,
                })
            if not lines and not t.internal_note and not t.general_customer_note:
                continue
            result.append({
                'id': t.id,
                'name': t.name,
                'ref': t.pos_reference or '',
                'tracking': t.tracking_number or '',
                'table': t.table_name or '',
                'floor': t.floor_name or '',
                'note': ' '.join(x for x in [t.internal_note, t.general_customer_note] if x),
                'state': t.state,
                'created_utc': t.create_date.isoformat() + 'Z' if t.create_date else None,
                'lines': lines,
            })
        return request.make_response(
            json.dumps({'tickets': result, 'now_utc': fields.Datetime.now().isoformat() + 'Z'}),
            headers=[('Content-Type', 'application/json'), ('Cache-Control', 'no-store')],
        )

    @http.route('/kds/set_state', auth='user', type='http', methods=['POST'], csrf=True)
    def kds_set_state(self, ticket_id=None, state=None, **kw):
        if not self._check_access() or state not in ('new', 'progress', 'done'):
            return request.make_response('{"ok": false}', headers=[('Content-Type', 'application/json')])
        ticket = request.env['ko.kds.ticket'].browse(int(ticket_id)).exists()
        if ticket:
            ticket.set_kds_state(state)
        return request.make_response('{"ok": true}', headers=[('Content-Type', 'application/json')])

    @http.route('/kds/toggle_line', auth='user', type='http', methods=['POST'], csrf=True)
    def kds_toggle_line(self, line_id=None, **kw):
        if not self._check_access():
            return request.make_response('{"ok": false}', headers=[('Content-Type', 'application/json')])
        line = request.env['ko.kds.ticket.line'].browse(int(line_id)).exists()
        if line:
            line.toggle_done()
        return request.make_response('{"ok": true}', headers=[('Content-Type', 'application/json')])
