import { patch } from "@web/core/utils/patch";
import { PosStore } from "@point_of_sale/app/services/pos_store";
import { changesToOrder } from "@point_of_sale/app/models/utils/order_change";

/**
 * KO KDS: every time an order is sent to the kitchen, also create a
 * KDS ticket on the server (ko.kds.ticket) so kitchen screens can show it.
 */
patch(PosStore.prototype, {
    async sendOrderInPreparation(order, opts = {}) {
        let kdsPayload = null;
        try {
            if (!opts.byPassPrint && !order.uiState?.isReprinting) {
                // All POS categories: server-side stations do the filtering.
                const allCategIds = new Set(this.models["pos.category"].map((c) => c.id));
                if (allCategIds.size) {
                    const change = changesToOrder(order, allCategIds, opts.cancelled);
                    const hasChanges =
                        change.new.length ||
                        change.cancelled.length ||
                        change.internal_note ||
                        change.general_customer_note;
                    if (hasChanges) {
                        kdsPayload = {
                            order_uuid: order.uuid,
                            pos_reference: order.pos_reference,
                            tracking_number: order.tracking_number,
                            config_id: this.config.id,
                            table: order.table_id ? order.table_id.table_number : null,
                            floor: order.table_id?.floor_id?.name || "",
                            internal_note: change.internal_note || "",
                            general_customer_note: change.general_customer_note || "",
                            new: change.new,
                            cancelled: change.cancelled,
                        };
                    }
                }
            }
        } catch (e) {
            console.warn("KDS: failed computing changes", e);
        }

        if (kdsPayload) {
            // Send to KDS first — the (optional) kitchen printer may be slow/offline.
            try {
                await this.data.call("ko.kds.ticket", "create_from_pos", [kdsPayload]);
            } catch (e) {
                // Offline or server error: kitchen printer (if any) still got the order.
                console.warn("KDS: failed sending ticket", e);
            }
        }
        return await super.sendOrderInPreparation(order, opts);
    },
});
