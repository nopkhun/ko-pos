/* KO KDS screen — vanilla JS, polls /kds/data */
(function () {
    "use strict";

    const POLL_MS = 3000;
    const board = document.getElementById("board");
    const clock = document.getElementById("clock");
    let knownTickets = new Set();
    let firstLoad = true;
    let audioCtx = null;

    function beep() {
        try {
            audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
            const o = audioCtx.createOscillator();
            const g = audioCtx.createGain();
            o.connect(g);
            g.connect(audioCtx.destination);
            o.type = "sine";
            o.frequency.value = 880;
            g.gain.setValueAtTime(0.4, audioCtx.currentTime);
            g.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.6);
            o.start();
            o.stop(audioCtx.currentTime + 0.6);
        } catch (e) { /* autoplay policy — ignore */ }
    }

    function fmtElapsed(ms) {
        const m = Math.floor(ms / 60000);
        const s = Math.floor((ms % 60000) / 1000);
        return (m < 10 ? "0" + m : m) + ":" + (s < 10 ? "0" + s : s);
    }

    function post(url, params) {
        params = Object.assign({ csrf_token: window.KDS_CSRF }, params);
        const body = new URLSearchParams(params);
        return fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: body.toString(),
        }).then(() => refresh());
    }

    window.kdsSetState = function (id, state) { post("/kds/set_state", { ticket_id: id, state: state }); };
    window.kdsToggleLine = function (ev, id) {
        ev.stopPropagation();
        post("/kds/toggle_line", { line_id: id });
    };

    function esc(s) {
        return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
        });
    }

    function render(data) {
        const tickets = data.tickets || [];
        const active = tickets.filter((t) => t.state !== "done");
        const doneRecent = tickets.filter((t) => t.state === "done").slice(-6);
        const nowServer = new Date(data.now_utc).getTime();
        const nowLocal = Date.now();
        const skew = nowLocal - nowServer;

        // Beep on new tickets
        const newIds = active.filter((t) => !knownTickets.has(t.id));
        if (!firstLoad && newIds.length) { beep(); }
        knownTickets = new Set(tickets.map((t) => t.id));
        firstLoad = false;

        if (!active.length && !doneRecent.length) {
            board.innerHTML = '<div class="empty">ยังไม่มีออเดอร์ 🎉</div>';
            return;
        }

        const html = active.concat(doneRecent).map((t) => {
            const created = new Date(t.created_utc).getTime() + skew;
            const elapsedMs = Math.max(0, Date.now() - created);
            const mins = elapsedMs / 60000;
            const elapsedCls = mins >= 10 ? "late" : mins >= 5 ? "warn" : "";
            const lines = t.lines.map((l) => {
                const cls = l.cancelled ? "cancelled" : l.done ? "done-line" : "";
                const noteParts = [l.attrs, l.note].filter(Boolean).join(" · ");
                return (
                    '<li class="' + cls + '" onclick="kdsToggleLine(event,' + l.id + ')">' +
                    '<span class="qty">' + (l.cancelled ? "✕" : "×" + esc(l.qty)) + "</span>" +
                    "<span>" + esc(l.name) +
                    (noteParts ? '<span class="note">📝 ' + esc(noteParts) + "</span>" : "") +
                    "</span></li>"
                );
            }).join("");

            let actions = "";
            if (t.state === "new") {
                actions =
                    '<button class="btn-start" onclick="kdsSetState(' + t.id + ",'progress')\">▶ เริ่มทำ</button>" +
                    '<button class="btn-done" onclick="kdsSetState(' + t.id + ",'done')\">✔ เสร็จ</button>";
            } else if (t.state === "progress") {
                actions = '<button class="btn-done" onclick="kdsSetState(' + t.id + ",'done')\">✔ เสร็จแล้ว</button>";
            } else {
                actions = '<button class="btn-undo" onclick="kdsSetState(' + t.id + ",'progress')\">↩ เอากลับ</button>";
            }

            const tableLabel = t.table ? "โต๊ะ " + esc(t.table) : (t.tracking ? "คิว " + esc(t.tracking) : esc(t.name));
            return (
                '<div class="card ' + t.state + '" data-id="' + t.id + '">' +
                '<div class="card-head"><span class="table-no">' + tableLabel + "</span>" +
                '<span class="ref">' + esc(t.floor || "") + "<br/>" + esc(t.name) + "</span></div>" +
                '<div class="elapsed ' + elapsedCls + '" data-created="' + created + '">⏱ ' + fmtElapsed(elapsedMs) + "</div>" +
                '<ul class="lines">' + lines + "</ul>" +
                (t.note ? '<div class="ticket-note">💬 ' + esc(t.note) + "</div>" : "") +
                '<div class="actions">' + actions + "</div>" +
                "</div>"
            );
        }).join("");
        board.innerHTML = html;
    }

    function refresh() {
        return fetch("/kds/data?station_id=" + (window.KDS_STATION_ID || ""))
            .then((r) => r.json())
            .then(render)
            .catch(() => { /* offline: keep last state */ });
    }

    // Tick elapsed timers every second without re-fetching
    setInterval(function () {
        document.querySelectorAll(".elapsed[data-created]").forEach(function (el) {
            const created = parseInt(el.getAttribute("data-created"), 10);
            const ms = Math.max(0, Date.now() - created);
            const mins = ms / 60000;
            el.classList.toggle("late", mins >= 10);
            el.classList.toggle("warn", mins >= 5 && mins < 10);
            el.innerHTML = "⏱ " + fmtElapsed(ms);
        });
        if (clock) {
            clock.textContent = new Date().toLocaleTimeString("th-TH", { hour: "2-digit", minute: "2-digit" });
        }
    }, 1000);

    refresh();
    setInterval(refresh, POLL_MS);
})();
